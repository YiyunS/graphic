

#include <array>
#include <iostream>
#include <vector>
#include <sstream>
#include <cmath>
#include <cassert>	//assert

 // glad beforw glfw
#include "glad/glad.h"
//
#include "GLFW/glfw3.h"

#include "common_matrices.hpp"
#include "obj_mesh_file_io.hpp"
#include "obj_mesh.hpp"
#include "mat4f.hpp"
#include "mat3f.hpp"
#include "shader.hpp"
#include "program.hpp"
#include "triangle.hpp"
#include "vec3f.hpp"
#include "vec2f.hpp"
#include "shader_file_io.hpp"
#include "buffer_object.hpp"
#include "vertex_array_object.hpp"
#include "vbo_tools.hpp"
#include "texture.hpp"
#include "image.hpp"

using namespace math;
using namespace geometry;
using namespace opengl;

// GLOBAL Variables
Mat4f g_M = Mat4f::identity();
Mat4f g_V = Mat4f::identity();
Mat4f g_P = Mat4f::identity();
float step = 50;
GLuint width_ord = 1000, height_ord = 1000;
double number;
float x_position;
float y_position;

Vec3f viewPos(0, 0, 5);
Vec3f lightPos(0, 0, 5);
Vec3f lightColor(1 ,1 ,1);
int hit = -1;
bool end_i = true;
float degree_convert = 0.017453;
// function declaration
using namespace std;
vector<Vec3f> controlPoints;
vector<Vec3f> pottery;
vector<Vec3f> potteryNormals;
vector<Vec3f> tmp;
vector<Vec3f> empty;
vector<int> v;
void setFrameBufferSize(GLFWwindow *window, int width, int height) {
	width_ord = width;
	height_ord = height;
	glViewport(0, 0, width_ord, height_ord);
	g_P = perspectiveProjection(30, float(width_ord) / height_ord, 0.01, 100.f);
}

void setKeyboard(GLFWwindow *window, int key, int scancode, int action, int mods) {
	if (GLFW_KEY_LEFT == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			g_M = rotateAboutYMatrix(5) * g_M;
		}
	}
	else if (GLFW_KEY_RIGHT == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			g_M = rotateAboutYMatrix(-5) * g_M;
		}
	}
	else if (GLFW_KEY_UP == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			g_M = uniformScaleMatrix(1.1) * g_M;
		}
	}
	else if (GLFW_KEY_DOWN == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			g_M = uniformScaleMatrix(1. / 1.1) * g_M;
		}
	}
	else if (GLFW_KEY_W == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			g_M = translateMatrix(0, 0.1, 0) * g_M;
		}
	}
	else if (GLFW_KEY_S == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			g_M = translateMatrix(0, -0.1, 0) * g_M;
		}
	}
	else if (GLFW_KEY_D == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			g_M = translateMatrix(0.1, 0, 0) * g_M;
		}
	}
	else if (GLFW_KEY_A == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			g_M = translateMatrix(-0.1, 0, 0) * g_M;
		}
	}
	else if (GLFW_KEY_X == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			number = glfwGetTime() - number;
			if(number >= 0.5 && controlPoints.size() > 2){
					tmp = empty;
					for(int n = 0; n < hit; n++){
						tmp.push_back(controlPoints[n]);
					}
					for(int i = hit+1; i < controlPoints.size(); i++){
						tmp.push_back(controlPoints[i]);
					}
					controlPoints = tmp;
					tmp = empty;
					hit = -1;
			}
			number = glfwGetTime();
		}
	}
	else if (GLFW_KEY_Z == key) {
		if (GLFW_REPEAT == action || GLFW_PRESS == action) {
			number = glfwGetTime() - number;
			if(number >= 0.5){
				tmp.push_back(Vec3f(0.2,0.2,1));
				for(int n = 0; n < controlPoints.size(); n++){
					tmp.push_back(controlPoints[n]);
				}
				controlPoints = tmp;
				tmp = empty;
			}
			number = glfwGetTime();
		}
	}
	else if (GLFW_KEY_ESCAPE == key) {
		glfwSetWindowShouldClose(window, GLFW_TRUE);
	}
}

//curve to pottery
Vec3f curve_to_stuff(Vec3f p){
	float hypotenuse = sqrt(pow(p.x,2.f) + pow(p.z,2.f));
	float degree = asin(p.z/hypotenuse)/degree_convert;
	float x,z;
	if(p.x >= 0){
		degree += 1;
		z = hypotenuse * sin(degree*degree_convert);
		x = sqrt(pow(hypotenuse,2.f) - z*z);
	}else{
		degree -= 1;
		z = hypotenuse * sin(degree*degree_convert);
		x = -sqrt(pow(hypotenuse,2.f) - z*z);
	}
	if(degree > 90 || degree < -90){
		x = -x;
	}
	return(Vec3f(x, p.y, z));
}


opengl::Program createShaderProgram(std::string const &vertexShaderFile,
	std::string const &fragmentShaderFile) {
	using namespace opengl;
	auto vertexShaderSource = loadShaderStringFromFile(vertexShaderFile);
	auto fragmentShaderSource = loadShaderStringFromFile(fragmentShaderFile);

	std::cout << "[Log] compiling program " << vertexShaderFile << ' '
		<< fragmentShaderFile << '\n';
	return opengl::makeProgram(vertexShaderSource, fragmentShaderSource);
}

//as2
opengl::Program createShaderProgram(std::string const &vertexShaderFile,
                                    std::string const &geometryShaderFile,
                                    std::string const &fragmentShaderFile) {
  using namespace opengl;
  auto vertexShaderSource = loadShaderStringFromFile(vertexShaderFile);
  auto geometryShaderSource = loadShaderStringFromFile(geometryShaderFile);
  auto fragmentShaderSource = loadShaderStringFromFile(fragmentShaderFile);

  std::cout << "[Log] compiling program " << vertexShaderFile << ' '
            << geometryShaderFile << ' ' << fragmentShaderFile << '\n';
  return opengl::makeProgram(vertexShaderSource, geometryShaderSource,
                             fragmentShaderSource);
}
std::string glfwVersion() {
	std::ostringstream s("GLFW version: ", std::ios::in | std::ios::ate);
	// print version
	int glfwMajor, glfwMinor, glfwRevision;
	glfwGetVersion(&glfwMajor, &glfwMinor, &glfwRevision);
	s << glfwMajor << '.' << glfwMinor << '.' << glfwRevision;
	return s.str();
}

bool loadGeometryToGPU(std::vector<Vec3f> const &vertices, GLuint vboID) {
	glBindBuffer(GL_ARRAY_BUFFER, vboID);
	glBufferData(
		GL_ARRAY_BUFFER,                  // destination
		sizeof(Vec3f) * vertices.size(), // size (bytes) of memcopy to GPU
		vertices.data(),                  // pointer to data (contiguous)
		GL_STATIC_DRAW                    // usage patter of the GPU buffer
	);

	return true;
}

//asking in tur
std::vector<Vec3f> getsubdividePoints(std::vector<Vec3f> const & points, float n) {
	std::vector<Vec3f> tmp;
	if(points.size() == 1){return points;}
	else{
		for(int i = 0; i < points.size()-1; i++){
			Vec3f curve_point;
			curve_point = points[i+1] - points[i];
			curve_point = curve_point * n;
			curve_point = points[i] + curve_point;
			tmp.push_back(curve_point);
		}
	}
	return getsubdividePoints(tmp, n);
}

//asking in tur
std::vector<Vec3f> subdivideOpenCurve(std::vector<Vec3f> const & points, float step) {
	std::vector<Vec3f> out;
	if(points.size() <= 1){return points;}
	else if(points.size() == 2){
		out.push_back(points[0]);
		Vec3f curve_point;
		curve_point = points[1] - points[0];
		curve_point = curve_point * 0.5;
		curve_point = points[0] + curve_point;
		out.push_back(curve_point);
		out.push_back(points[points.size()-1]);
	}
	else{
		for(float i = step; i < 1; i+=step){
			std::vector<Vec3f> tmp;
			tmp = getsubdividePoints(points, i);
			out.push_back(tmp[0]);
		}
		out.push_back(points[points.size()-1]);
	}
	return out;
}

//moving points
void move(double dx, double dy, double x_coor, double y_coor, std::vector<Vec3f> controlPoints){
	x_position = x_coor/width_ord*2 - 1;
	y_position = -y_coor/height_ord*2 + 1;
	for(int i = 0; i < controlPoints.size(); i++){
		if (controlPoints[i].x -0.05 < x_position && x_position < controlPoints[i].x + 0.05 && controlPoints[i].y - 0.05 < y_position && y_position < controlPoints[i].y + 0.05){
				hit = i;
		}
	}
	if(hit != -1){
		controlPoints[hit].x += dx/width_ord*2;
		controlPoints[hit].y += -dy/height_ord*2;
	}
	tmp = controlPoints;
	return;
}

std::vector<Vec3f> set_to_pottery(std::vector<Vec3f> point){
	for(int i =0; i < point.size(); i++){
		point[i].z -= 1;
	}
	std::vector<Vec3f> curve_point;
	tmp = empty;
	for(int j = 0; j < 360; j++){
		for(int i = 0; i < point.size(); i++){
			//point[i].z -= 1;
			tmp.push_back(point[i]);
			tmp.push_back(curve_to_stuff(point[i]));
		}
		for(int i = 3; i < tmp.size(); i+=2){
			curve_point.push_back(tmp[i-3]);
			curve_point.push_back(tmp[i-2]);
			curve_point.push_back(tmp[i-1]);
			curve_point.push_back(tmp[i-1]);
			curve_point.push_back(tmp[i-2]);
			curve_point.push_back(tmp[i]);
		}
		for(int i = 0; i < point.size(); i++){
			point[i] = curve_to_stuff(point[i]);
		}
		tmp = empty;
	}
	return curve_point;
}

std::vector<int> get_point_position(std::vector<Vec3f> point){
	std::vector<int> vertices;
	for(int j = 0; j < 360; j++){
		vertices.push_back(j*point.size());
		vertices.push_back(j*point.size()+1);
		for(int i = 2; i < point.size(); i++){
			vertices.push_back(j*point.size()+i);
			vertices.push_back(j*point.size()+i+1);
			vertices.push_back(j*point.size()+i);
			vertices.push_back(j*point.size()+i+1);
		}
		vertices.push_back(j*point.size()+point.size()-2);
		vertices.push_back(j*point.size()+point.size()-1);
	}
	return vertices;
}

//obj_mesh.cpp from as2
std::vector<Vec3f> calculateTrianglnormals(std::vector<Vec3f> point){
	std::vector<Vec3f> tmp;
	for(int i = 0; i < point.size(); i+=6){
		Vec3f a = point[i];
		Vec3f b = point[i+1];
		Vec3f c = point[i+2];
		Vec3f normal = (b-a)^(c-a);
		tmp.push_back(normalized(normal));
	}
	return tmp;
}

//obj_mesh.cpp from as2
std::vector<Vec3f> calculateVertexNormals(std::vector<Vec3f> p, std::vector<Vec3f> a){
	tmp = empty;
	std::vector<Vec3f> normal_1 = calculateTrianglnormals(p);
	for(int i=0; i< a.size()*360; i++){
		tmp.push_back({0,0,0});
	}
	std::vector<int> v = get_point_position(a);
	for(int i = 0; i < normal_1.size(); i++){
		Vec3f normal_2 = normal_1[i];
		tmp[v[i]]+=normal_2;
		tmp[v[i+1]]+=normal_2;
		tmp[v[i+2]]+=normal_2;
	}

	std::vector<Vec3f> normal;
	int count = 0;
	if(a[0].x == 0){
		for(int i = 0; i < 360; i++){
			tmp[2*a.size()*i] = {0, 1, 0};
			tmp[2*a.size()*i+1] = {0, 1, 0};
		}
	}
	if(a[a.size()-1].x == 0){
		for(int i = 1; i < 361; i++){
			tmp[2*a.size()*i-2] = {0, -1, 0};
			tmp[2*a.size()*i-1] = {0, -1, 0};
		}
	}
	normal = tmp;
	tmp = empty;
	for(int i=0; i<normal.size(); i++){
		normal[i] = normalized(normal[i]);
	}
	return normal;
}



void setupVAO(GLuint vaoID, GLuint vboID) {

	glBindVertexArray(vaoID);
	glBindBuffer(GL_ARRAY_BUFFER, vboID);

	// set up position input into vertex shader
	glEnableVertexAttribArray(0);          // match layout # in shader
	glVertexAttribPointer(                 //
		0,                                 // attribute layout # (in shader)
		3,                                 // number of coordinates per vertex
		GL_FLOAT,                          // type
		GL_FALSE,                          // normalized?
		sizeof(Vec3f),                    // stride
		0									 // array buffer offset
	);

	glBindVertexArray(0);
}


void setupVAONormal(GLuint vaoID, GLuint vboID) {

	glBindVertexArray(vaoID);
	glBindBuffer(GL_ARRAY_BUFFER, vboID);

	glEnableVertexAttribArray(0); // match layout # in vertex shader
	glVertexAttribPointer(        //
		0,                        	// attribute layout # (in shader)
		3,                        	// number of coordinates per vertex
		GL_FLOAT,                 	// type
		GL_FALSE,                 	// normalized?
		sizeof(Vec3f),      				// stride
		(void *)(0)  								// array buffer offset
		);

	//from vbo_tools
	glEnableVertexAttribArray(1); 	// match layout # in vertex shader
	glVertexAttribPointer(        	//
		1,                        		// attribute layout # (in shader)
		3,                     	   		// number of coordinates per vertex
		GL_FLOAT,               	  	// type
		GL_FALSE,                		 	// normalized?
		sizeof(Vec3f),      					// stride
		(void *)(sizeof(Vec3f) * pottery.size())   // array buffer offset
	);


	glBindVertexArray(0);
}

GLFWwindow *initWindow() {
	GLFWwindow *window = nullptr;

	if (!glfwInit()) {
		exit(EXIT_FAILURE);
	}

	std::cout << glfwVersion() << '\n';

	// set opengl version
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
	glfwWindowHint(GLFW_SAMPLES, 4);

	window = glfwCreateWindow(width_ord,           // width
		height_ord,           // height
		"Mesh Loading", // title
		NULL,           // unused
		NULL);
	if (!window) {
		glfwTerminate();
		exit(EXIT_FAILURE);
	}

	glfwMakeContextCurrent(window);
	gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);

	glfwSwapInterval(1); // vsync
	glEnable(GL_MULTISAMPLE);
	glEnable(GL_DEPTH_TEST);
	// glEnable(GL_CULL_FACE);
	// glCullFace(GL_BACK);

	//Polygon fill mode
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	// setup callbacks
	glfwSetFramebufferSizeCallback(window, setFrameBufferSize);
	glfwSetKeyCallback(window, setKeyboard);

	return window;
}

int main() {
	double  yoffset, x_coor, y_coor;
	GLFWwindow *window = initWindow();

	auto vao_control = makeVertexArrayObject();
	auto vbo_control = makeBufferObject();
	auto vao_curve = makeVertexArrayObject();
	auto vbo_curve = makeBufferObject();

	auto vao_pottery = makeVertexArrayObject();
	auto vbo_pottery = makeBufferObject();
	auto vao_pottery_normal = makeVertexArrayObject();
	auto vbo_pottery_normal = makeBufferObject();

	Vec3f viewPosition(0, 0, 3);
	g_V = lookAtMatrix(viewPosition,    // eye position
		{ 0.f, 0.f, 0.f }, // look at
		{ 0.f, 1.f, 0.f }  // up vector
	);
	g_P = orthographicProjection(-1, 1, 1, -1, 0.001f, 10);

	auto basicShader = createShaderProgram("../shaders/basic_vs.glsl",
		"../shaders/basic_fs.glsl");
	// auto depthShader = createShaderProgram("../shaders/depth_vs.glsl",
	// 									"../shaders/depth_fs.glsl");
  // auto normalShader = createShaderProgram("../shaders/normal_vs.glsl",
  //                                       "../shaders/normal_fs.glsl");
 	auto textureShader = createShaderProgram("../shaders/texture_vs.glsl",
									 "../shaders/texture_gs.glsl",
									 "../shaders/texture_fs.glsl");
	assert(basicShader && textureShader);	//Check console for program compilation error
	textureShader.use();
  //setUniformVec3f(depthShader.uniformLocation("lightPosition"), lightPosition);
	//opengl::Program *program = &textureShader;
	opengl::Program *program = &basicShader;
	setupVAO(vao_control.id(), vbo_control.id());
	setupVAO(vao_curve.id(), vbo_curve.id());
	setupVAONormal(vao_pottery.id(), vbo_pottery.id());
	setupVAONormal(vao_pottery_normal.id(), vbo_pottery_normal.id());
	//Load control points
	controlPoints.push_back({ 0,0.5,1 });
	controlPoints.push_back({ 0.5,0,1 });
	controlPoints.push_back({ 0.5,-0.5,1 });
	controlPoints.push_back({ 0.2,-0.7,1 });

	loadGeometryToGPU(controlPoints, vbo_control.id());

	//Load curve points
	std::vector<Vec3f> outCurve;
	outCurve = subdivideOpenCurve(controlPoints, 1/step);	//TODO - insert subdivision here
	loadGeometryToGPU(outCurve, vbo_curve.id());

	Vec3f color_curve(0, 1, 1);
	Vec3f color_control(1, 0, 0);
	//Set to one shader program

	glPointSize(10);

	glfwGetCursorPos(window, &x_coor, &y_coor);
	double x_ord = x_coor;
	double y_ord = y_coor;

	int width, height;
  number = glfwGetTime();

	pottery = set_to_pottery(outCurve);
	loadGeometryToGPU(pottery, vbo_pottery.id());
	potteryNormals = calculateVertexNormals(pottery, outCurve);
	loadGeometryToGPU(potteryNormals, vbo_pottery_normal.id());
	v = get_point_position(outCurve);
	float shading = 2;
	while (!glfwWindowShouldClose(window)) {

		glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

		program->use();
		setUniformMat4f(program->uniformLocation("model"), g_M, true);
		setUniformMat4f(program->uniformLocation("view"), g_V, true);
		setUniformMat4f(program->uniformLocation("projection"), g_P, true);
		setUniformVec3f(textureShader.uniformLocation("lightPosition"), lightPos);
		glfwGetCursorPos(window, &x_coor, &y_coor);
    setUniform1f(textureShader.uniformLocation("shading"), shading);
		//as2
		if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS){
			move(x_coor-x_ord, y_coor-y_ord, x_coor, y_coor, controlPoints);
			controlPoints = tmp;
			tmp = empty;
		}
		loadGeometryToGPU(controlPoints, vbo_control.id());
		x_ord = x_coor;
		y_ord = y_coor;

		outCurve = subdivideOpenCurve(controlPoints, 1/step);
		loadGeometryToGPU(outCurve, vbo_curve.id());
		loadGeometryToGPU(controlPoints, vbo_control.id());

		pottery = set_to_pottery(outCurve);
		loadGeometryToGPU(pottery, vbo_pottery.id());
		potteryNormals = calculateVertexNormals(pottery, outCurve);
		loadGeometryToGPU(potteryNormals, vbo_pottery_normal.id());
		v = get_point_position(outCurve);

		program->use();

		basicShader.use();
		program = &basicShader;

		//Draw curve
		setUniformVec3f(basicShader.uniformLocation("color"), color_curve);
		vao_curve.bind();

		glDrawArrays(GL_LINE_STRIP,   // type of drawing (rendered to back buffer)
			0,						  // offset into buffer
			outCurve.size()	// number of vertices in buffer
		);

		//Draw control points
		setUniformVec3f(basicShader.uniformLocation("color"), color_control);
		vao_control.bind();
		glDrawArrays(GL_LINE_STRIP,   // type of drawing (rendered to back buffer)
			0,						  // offset into buffer
			controlPoints.size()	// number of vertices in buffer
		);

		glDrawArrays(GL_POINTS,   // type of drawing (rendered to back buffer)
			0,						  // offset into buffer
			controlPoints.size()	// number of vertices in buffer
		);
		setUniformVec3f(basicShader.uniformLocation("color"), Vec3f(0.5, 0.5, 0.5));
		vao_pottery.bind();
		textureShader.use();
		program = &textureShader;
		glDrawArrays(GL_TRIANGLES,   // type of drawing (rendered to back buffer)
					0,						  // offset into buffer
					pottery.size()	// number of vertices in buffer
		);

		glfwSwapBuffers(window); // swaps back buffer to front for drawing to screen
		glfwPollEvents();        // will process event queue and carry on
	}

	// cleaup window, and glfw before exit
	glfwDestroyWindow(window);
	glfwTerminate();

	return EXIT_SUCCESS;
}
