## README.md

## Description

Overview
	Write a program for the interactive modeling and rendering of pottery. Assume that the
	pottery is a surface of revolution.
Basic features
	� The generating curve (i.e., the curve being revolved) is a subdivision curve or a
	parametric curve. The user should be able to edit this curve by inserting, deleting,
	and moving control points.
	� You may use different viewports to edit the generating curve and display the
	pottery.
	� The pottery should be rendered with Phong shading.

The project now includes its own version of glad AND glfw that need to be
compiled with project. This should happen automatically with any of the options
below for installation.

## Configure

### Unix makefile (Tested)
	cmake -H. -Bbuild

### Mac OSX (Tested)
	cmake -H. -Bbuild -G "Xcode"

### Microsoft Windows (Tested - if you have Visual Studio 2017)
	(Change to "Visual Studio 16" if you have Visual Studio 2019)
	cmake -H. -Bbuild -G "Visual Studio 15"

or

	cmake -H. -Bbuild -G "Visual Studio 15 Win64"

## USAGE

	build/Curves
