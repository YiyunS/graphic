glad
====

This branch contains an OpenGL loader generated with `glad` for the C programming
language.

    python2 main.py --out-path=./ --generator=c

It includes all functions needed for a OpenGL 4.4 compatability context including
all extensions found in `gl.xml` fetched on 4th August 2013.